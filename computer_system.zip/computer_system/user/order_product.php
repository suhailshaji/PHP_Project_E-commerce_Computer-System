<?php
 session_start();

 $pid = $_REQUEST['pid'];
 include '../include/config.php';

  
        ?>


<!DOCTYPE html>

<html
  lang="en"
  class="light-style layout-menu-fixed"
  dir="ltr"
  data-theme="theme-default"
  data-assets-path="../assets/"
  data-template="vertical-menu-template-free"
>
  <head>
    <meta charset="utf-8" />
    <meta
      name="viewport"
      content="width=device-width, initial-scale=1.0, user-scalable=no, minimum-scale=1.0, maximum-scale=1.0"
    />

    <title>View Product</title>

    <meta name="description" content="" />


    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link
      href="https://fonts.googleapis.com/css2?family=Public+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;1,300;1,400;1,500;1,600;1,700&display=swap"
      rel="stylesheet"
    />

    <!-- Icons. Uncomment required icon fonts -->
    <link rel="stylesheet" href="../assets/vendor/fonts/boxicons.css" />

    <!-- Core CSS -->
    <link rel="stylesheet" href="../assets/vendor/css/core.css" class="template-customizer-core-css" />
    <link rel="stylesheet" href="../assets/vendor/css/theme-default.css" class="template-customizer-theme-css" />
    <link rel="stylesheet" href="../assets/css/demo.css" />

    <!-- Vendors CSS -->
    <link rel="stylesheet" href="../assets/vendor/libs/perfect-scrollbar/perfect-scrollbar.css" />

    <!-- Page CSS -->

    <!-- Helpers -->
    <script src="../assets/vendor/js/helpers.js"></script>

    <!--! Template customizer & Theme config files MUST be included after core stylesheets and helpers.js in the <head> section -->
    <!--? Config:  Mandatory theme config file contain global vars & default theme options, Set your preferred theme option in this file.  -->
    <script src="../assets/js/config.js"></script>
  </head>

  <body>
    <!-- Layout wrapper -->
    <div class="layout-wrapper layout-content-navbar layout-without-menu">
      <div class="layout-container">
        <!-- Layout container -->
        <div class="layout-page">
          <!-- Navbar -->

          <nav
            class="layout-navbar container-xxl navbar navbar-expand-xl navbar-detached align-items-center bg-navbar-theme"
            id="layout-navbar"
          >
            <div class="navbar-nav-right d-flex align-items-center" id="navbar-collapse">
            Order
           
              <!-- Search -->
              <div class="navbar-nav align-items-center">
                <div class="nav-item d-flex align-items-center">
            
                 
          
                </div>
              </div>
              <!-- /Search -->

              <ul class="navbar-nav flex-row align-items-center ms-auto">
                <!-- Place this tag where you want the button to render. -->
              
                    <li>
                      <a class="dropdown-item" href="myorder.php">
                        <span class="d-flex align-items-center align-middle">
                          <i class="flex-shrink-0 bx bx-credit-card me-2"></i>
                          <span class="flex-grow-1 align-middle">My Order</span>
                          <!-- <span class="flex-shrink-0 badge badge-center rounded-pill bg-danger w-px-20 h-px-20">4</span> -->
                        </span>
                      </a>
                    </li>

                <!-- User -->
                <li class="nav-item navbar-dropdown dropdown-user dropdown">
                  <a class="nav-link dropdown-toggle hide-arrow" href="javascript:void(0);" data-bs-toggle="dropdown">
                    <div class="avatar avatar-online">
                    
                    </div>
                  </a>
                  <ul class="dropdown-menu dropdown-menu-end">
                    <li>
                      <a class="dropdown-item" href="#">
                        <div class="d-flex">
                          <div class="flex-shrink-0 me-3">
                            <div class="avatar avatar-online">
                       
                            </div>
                          </div>
                          <div class="flex-grow-1">
                         
                            <small class="text-muted">Customer</small>
                          </div>
                        </div>
                      </a>
                    </li>
                   
                    <li>
                      <a class="dropdown-item" href="myorder.php">
                        <span class="d-flex align-items-center align-middle">
                          <i class="flex-shrink-0 bx bx-credit-card me-2"></i>
                          <span class="flex-grow-1 align-middle">My Order</span>
             
                        </span>
                      </a>
                    </li>
                    <li>
                      <div class="dropdown-divider"></div>
                    </li>
                    <li>
                      <a class="dropdown-item" href="user_login.php">
                        <i class="bx bx-power-off me-2"></i>
                        <span class="align-middle">Log Out</span>
                      </a>
                    </li>
                  </ul>
                </li>
                <!--/ User -->
              </ul>
            </div>
          </nav>

          <!-- / Navbar -->

          <!-- Content wrapper -->
          <div class="content-wrapper">
            <!-- Content -->
   
    

<div class="col">


<div class="col">

           
    <br>
    <br>

            <!-- Content -->

            <div class="container-xxl flex-grow-1 container-p-y">
<!-- Horizontal -->
        <h5 class="pb-1 mb-4">Buy Now</h5>
        <?php
						  include '../include/config.php';
						$sel = "SELECT * FROM product where pid= '$pid'  ";
						$rs = $conn->query($sel);
						while($row = $rs->fetch_assoc()){
			?>
              <div class="row mb-5">
                
                <div class="col-md">
             
                  <div class="card shadow-none  border border-success mb-3">
                    <div class="row g-0">
                      <div class="col-md-4">
                        <img class="card-img card-img-left" src="../admin/image/<?php echo $row['image'];?>"    alt="Card image cap" />
                      </div>
                      <div class="col-md-8">
                        <div class="card-body">
                        <h4 class="card-title"><?php echo $row['product_name'] ?>  - <?php echo $row['model'] ?></h5>
                        <h4 class="card-title" style="color:green;">₹ <?php echo $row['price'] ?></h5>
                        <div class="card mb-4">
                    <ul class="list-group list-group-flush">
                      <li class="list-group-item">Model: <?php echo $row['model'] ?></li>
                      <li class="list-group-item">Brand: <?php echo $row['brand'] ?></li>
                      
                    </ul>
                    </div>
                    <div class="d-flex justify-content-between w-100">
                             
                          <a
                            href="javascript:void(0);"
                            class="list-group-item list-group-item-action flex-column align-items-start"
                          >
                      
                            <div class="d-flex justify-content-between w-100">
                              <h6 style="color:red;"> Save Extra with 3 offers</h6>
                              <small class="text-muted">Partner Offers</small>
                            </div>
                            <p class="mb-1">
                            Bank Offer 10% off on Citi Credit Card Transactions, up to ₹1,500. On orders of ₹5,000 and above
                            </p>
                            <small class="text-muted"  data-bs-toggle="modal"
                          data-bs-target="#modalScrollable"    ><mark>T & C </mark></small>
                          </a>
                          <a
                            href="javascript:void(0);"
                            class="list-group-item list-group-item-action flex-column align-items-start"
                          >
                            <div class="d-flex justify-content-between w-100">
                            <h6 style="color:red;"> No Cost EMI:</h6>
                                         <small class="text-muted">Partner Offers</small>
                            </div>
                            <p class="mb-1">
                            Bank Offer 12% off on Citi Credit Card EMI Transactions, up to ₹2,000. On orders of ₹5,000 and above
                            </p>
                            <small class="text-muted"  data-bs-toggle="modal"
                            data-bs-target="#modalScrollable"    ><mark>T & C </mark></small>
                          </a>
                        </div>
                      </div>
                    </div>
                   
                    
                    
             
                  </div>
                  
                       
                        </div>
                      </div>
                    
                    
                    </div>
                    <div class="card mb-4">
                    <h5 class="card-header">Order Product</h5>
                    <!-- Account -->
                    <div class="card-body">
                      <div class="d-flex align-items-start align-items-sm-center gap-4">
                        <img
                          src="../admin/image/<?php echo $row['image'];?>" 
                          alt="user-avatar"
                          class="d-block rounded"
                          height="100"
                          width="100"
                          id="uploadedAvatar"
                        />
                        <div class="button-wrapper">
                          <label for="upload" class="btn btn-primary me-2 mb-4" tabindex="0">
                            <span class="d-none d-sm-block">Product - <?php echo $row['product_name'] ?></span>
                            <i class="bx bx-upload d-block d-sm-none"></i>
                        
                           
                          </label>
                         

                          <p class="text-muted mb-0">Safe and Secure Payments</p>
                        </div>
                      </div>
                    </div>
                    <hr class="my-0" />
                    <div class="card-body">
                        <?php
                        $userid=  $_SESSION['userid'];
                        $query = "select  * FROM user WHERE userid= '$userid'";
                        $result = $conn->query($query);
                        while($rs = $result->fetch_assoc()){
                        ?>

                      <form id="formAccountSettings" method="POST" onsubmit="return false"> 
                        <div class="row">
                          <div class="mb-3 col-md-6">
                            <label for="firstName" class="form-label">Full Name</label>
                            <input
                              class="form-control"
                              type="text"
                              id="firstName"
                              name="firstName"
                              value=<?php echo $rs['name'] ?>
                              autofocus
                           readonly
                            />
                          </div>
                        
                          <div class="mb-3 col-md-6">
                            <label for="email" class="form-label">E-mail</label>
                            <input
                              class="form-control"
                              type="text"
                              id="email"
                              name="email"
                              value=<?php echo $rs['email'] ?>

                              readonly
                            />
                          </div>
                        
                          <div class="mb-3 col-md-6">
                            <label class="form-label" for="phoneNumber">Phone Number</label>
                            <div class="input-group input-group-merge">
                              <span class="input-group-text">(+91)</span>
                              <input
                                type="text"
                                id="phoneNumber"
                                name="phoneNumber"
                                class="form-control"
                                value=<?php echo $rs['mobile'] ?>   
                                placeholder="202 555 0111"
                                readonly
                              />
                            </div>
                          </div>
                          <div class="mb-3 col-md-6">
                            <label for="address" class="form-label">Address</label>
                            <input type="text" class="form-control" id="address" name="address"  value=<?php echo $rs['address'] ?>   readonly  placeholder="Address" />
                          </div>
                          <div class="mb-3 col-md-6">
                            <label for="state" class="form-label">City</label>
                            <input class="form-control" type="text" id="state" name="state" value=<?php echo $rs['address'] ?> readonly placeholder="California" />
                          </div>
                          
                        </div>
                       
                      </form>
                    </div>
                    <!-- /Account -->
                  </div>
                  <div class="card">
                    <h5 class="card-header">Order Summary</h5>
                    <div class="card-body">
                      <div class="mb-3 col-12 mb-0">
                        <div class="alert alert-success">
                          <h6 class="alert-heading fw-bold mb-1">Confirm Your Order</h6>
                          &nbsp;
                          <h4 class="card-title" style="color:green;"> Price &nbsp; &nbsp; &nbsp; &nbsp&nbsp; &nbsp; &nbsp&nbsp; &nbsp; &nbsp&nbsp; &nbsp; &nbsp&nbsp; &nbsp; &nbsp; &nbsp; -&nbsp; &nbsp; &nbsp; &nbsp;    ₹ <?php echo $row['price'] ?></h5>
                          <h4 class="card-title" style="color:green;"> Delivery Charge &nbsp; &nbsp; &nbsp; &nbsp; -&nbsp; &nbsp; &nbsp; &nbsp;     Free</h5>
                          <p class="mb-0">review your order before it's final.</p>
                        </div>
                      </div>
                     
                        <div class="form-check mb-3">
                          <input
                            class="form-check-input"
                            type="checkbox"
                            name="accountActivation"
                            id="accountActivation"  
                            checked
                          />
                          <label class="form-check-label" for="accountActivation"
                            >COD</label
                          >
                        </div>

                        <form method="post" action="">
                        <input type="submit" name="submit" value=" Buy Now "class="btn btn-danger deactivate-account">

                        <?php
                  if(isset($_POST["submit"]))
                  {
                    
                    
                      include '../include/config.php';
                      {
                      

                         $pid = $_REQUEST['pid'];
                          $userid = $_SESSION['userid'];
                         
                        
                          $currentdate = date('Y-m-d');
                          
                        {

                      
                      $sql="insert into order_product(pid,userid,order_date,status)VALUES('$pid','$userid','$currentdate','recived')";
                      if(mysqli_query($conn,$sql))
                          {
                        echo "<script type = \"text/javascript\">
                                      alert(\"Order Completed\");
                                                          window.location = (\"myorder.php\")
                                                          
                                      
                                      </script>";


                                                          

                                                          
                      
                      }   
                    else
                    {
                      echo mysqli_error($conn);
                    }
                  }
                  mysqli_close($conn);
                  } }
                  ?>




                      </form>
                    </div>
                  </div>
                </div>
              </div>
            </div>
                  </div>
                  
                </div>

                <div class="modal fade" id="modalScrollable" tabindex="-1" aria-hidden="true">
                        <div class="modal-dialog modal-dialog-scrollable" role="document">
                          <div class="modal-content">
                            <div class="modal-header">
                              <h5 class="modal-title" id="modalScrollableTitle">  Terms and Conditions</h5>
                              <button
                                type="button"
                                class="btn-close"
                                data-bs-dismiss="modal"
                                aria-label="Close"
                              ></button>
                            </div>
                            <div class="modal-body">
                              <p>
                              Frequently Asked Questions
                              </p>
                              <p>
                              What is the offer?
                              </p>
                              <p>
                              10% Instant Discount with Citi Credit & Debit Card (non-EMI transactions) and 12% Instant Discount with Credit Card (EMI transactions) on purchase of select categories.
                              </p>
                              <p>
                              How many times can this offer be applied?

                              </p>
                              <p>
                              There is no limit on the number of transactions. However, you can avail up to a Maximum Base Offer Discount of (INR 1,500 per Debit Card and INR 2,000) per Credit Card on select categories during the offer duration.
                              </p>
                              <p>
                              And a Maximum Bonus Offer Discount of INR 3,000 (Bonus Offer 1 - INR 1,000 + Bonus Offer 2 - INR 2,000) can be availed once per Credit Card across select categories combined during the offer duration.
                              </p>
                              <p>
                              Terms and Conditions:
                              </p>
                              <p>
                              Add on cards will be treated as separate cards.
                              </p>
                              <p>
                              The Offer is not applicable for Card on delivery transactions.
                              </p>
                              <p>
                              Customers are not bound in any way to participate in the Offer. Any such participation is voluntary and the same is being made purely on a best effort basis.

                              </p>
                              <p>
                              Citi holds the exclusive right at its sole discretion to refuse or deny the Offer to any Cardholder. The Cardholder shall become ineligible to participate in the Offer if his/her card is cancelled before the expiry of /during the Offer Periods.
                              </p>
                              <p>
                              All applicable taxes, liabilities or charges payable to the Government or any other authority or body, if any, shall be borne directly by the Cardholder.
                              </p>
                              <p>
                              Under no circumstances will the Offer/ Savings being offered be settled in cash.
                              </p>
                              <p>
                              Further, as required by applicable law, in the event that the Cardholder makes a purchase of an amount equal to or above Rs. 2,00,000, the Cardholder will be required to upload a scanned copy of his/her PAN card on the Platform, within 4 days of making the purchase, failing which, the purchase made by the Cardholder will be cancelled. The requirement to submit the PAN card arises only once and if it has been submitted once by the Cardholder, it need not be submitted again. The order of the Cardholder will be cancelled if there is a discrepancy between the name of the Cardholder and the name on the PAN Card.
                              </p>
                              <p>
                              This document is an electronic record in terms of Information Technology Act, 2000, and the Rules there under as applicable and the amended provisions pertaining to electronic records in various statutes as amended by the Information Technology Act, 2000. This electronic record is generated by a computer system and does not require any physical or digital signatures.
                              </p>
                              
                            </div>
                            <div class="modal-footer">
                              <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">
                                Close
                              </button>
                            
                          </div>
                        </div>
                      </div>
                      
             
                <?php
				}
			?>

 <!-- build:js assets/vendor/js/core.js -->
 <script src="../assets/vendor/libs/jquery/jquery.js"></script>
    <script src="../assets/vendor/libs/popper/popper.js"></script>
    <script src="../assets/vendor/js/bootstrap.js"></script>
    <script src="../assets/vendor/libs/perfect-scrollbar/perfect-scrollbar.js"></script>

    <script src="../assets/vendor/js/menu.js"></script>
    <!-- endbuild -->

    <!-- Vendors JS -->
    <script src="../assets/vendor/libs/apex-charts/apexcharts.js"></script>

    <!-- Main JS -->
    <script src="../assets/js/main.js"></script>

    <!-- Page JS -->
    <script src="../assets/js/dashboards-analytics.js"></script>

    <!-- Place this tag in your head or just before your close body tag. -->
    <script async defer src="https://buttons.github.io/buttons.js"></script>
  </body>
</html>












      <?php
    }
      
        ?>
      