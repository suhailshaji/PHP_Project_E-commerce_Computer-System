<?php
 session_start();
 include '../include/config.php';
	$userid=  $_SESSION['userid'];
    $query = "select  * FROM user WHERE userid= '$userid'";
	$result = $conn->query($query);
    while($row = $result->fetch_assoc()){

  
        ?>


<!DOCTYPE html>
<html lang="en">
   <head>
      <!-- basic -->
      <meta charset="utf-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <!-- mobile metas -->
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <meta name="viewport" content="initial-scale=1, maximum-scale=1">
      <!-- site metas -->
      <title>Computer Assembly System</title>
      <meta name="keywords" content="">
      <meta name="description" content="">
      <meta name="author" content="">
      <!-- bootstrap css -->
      <link rel="stylesheet" href="../index/css/bootstrap.min.css">
      <!-- style css -->
      <link rel="stylesheet" href="../index/css/style.css">
      <!-- Responsive-->
      <link rel="stylesheet" href="../index/css/responsive.css">
      <!-- fevicon -->
      <link rel="icon" href="../index/images/fevicon.png" type="image/gif" />
      <!-- Scrollbar Custom CSS -->
      <link rel="stylesheet" href="../index/css/jquery.mCustomScrollbar.min.css">
      <!-- Tweaks for older IEs-->
      <link rel="stylesheet" href="https://netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.css">
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/fancybox/2.1.5/jquery.fancybox.min.css" media="screen">
      <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script><![endif]-->


   </head>
   <!-- body -->
   <body class="main-layout">
      <!-- loader  -->
  
      <!-- end loader -->
      <!-- header -->
      <header>
         <!-- header inner -->
         <div class="header">
            <div class="container-fluid">
               <div class="row">
                  <div class="col-xl-3 col-lg-3 col-md-3 col-sm-3 col logo_section">
                     <div class="full">
                        <div class="center-desk">
                           <div class="logo">
                        
                           </div>
                        </div>
                     </div>
                  </div>
                  <div class="col-xl-9 col-lg-9 col-md-9 col-sm-9">
                     <nav class="navigation navbar navbar-expand-md navbar-dark ">
                        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExample04" aria-controls="navbarsExample04" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-icon"></span>
                        </button>
                        <div class="collapse navbar-collapse" id="navbarsExample04">
                           <ul class="navbar-nav mr-auto">
                              <li class="nav-item active">
                                 <a class="nav-link" href="index.html">Home</a>
                              </li>
                          
                              <li class="nav-item d_none">
                                 <a class="nav-link" href="view_product.php">View Product</a>
                              </li>
                              <li class="nav-item d_none">
                                 <a class="nav-link" href="myorder.php">My Order</a>
                              </li>
                            
                              <li class="nav-item d_none">
                                 <a class="nav-link" href="./index.php">Logout</a>
                              </li>
                           </ul>
                        </div>
                     </nav>
                  </div>
               </div>
            </div>
         </div>
      </header>
      <!-- end header inner -->
      <!-- end header -->
      <!-- banner -->
      <section class="banner_main">
         <div id="banner1" class="carousel slide" data-ride="carousel">
            <ol class="carousel-indicators">
               <li data-target="#banner1" data-slide-to="0" class="active"></li>
               <li data-target="#banner1" data-slide-to="1"></li>
               <li data-target="#banner1" data-slide-to="2"></li>
               <li data-target="#banner1" data-slide-to="3"></li>
               <li data-target="#banner1" data-slide-to="4"></li>
            </ol>
            <div class="carousel-inner">
               <div class="carousel-item active">
                  <div class="container">
                     <div class="carousel-caption">
                        <div class="row">
                           <div class="col-md-6">
                              <div class="text-bg">
                                 <span>Computer And Laptop</span>
                                 <h1>Accessories</h1>
                                 <p>There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or </p>
                                 <a href="#">Buy Now </a> <a href="contact.html">Contact </a>
                              </div>
                           </div>
                           <div class="col-md-6">
                              <div class="text_img">
                                 <figure><img src="../index/images/pct.png" alt="#"/></figure>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
              
            </div>
            <a class="carousel-control-prev" href="#banner1" role="button" data-slide="prev">
            <i class="fa fa-chevron-left" aria-hidden="true"></i>
            </a>
            <a class="carousel-control-next" href="#banner1" role="button" data-slide="next">
            <i class="fa fa-chevron-right" aria-hidden="true"></i>
            </a>
         </div>
      </section>



   
             

<div class="col">


<div class="col">
    <br>
    <br>

            <!-- Content -->

            <div class="container-xxl flex-grow-1 container-p-y">


           
            
              <div class="row row-cols-1 row-cols-md-5 g-4 mb-5">
              <?php
						  include '../include/config.php';
						$sel = "SELECT * FROM product  ";
						$rs = $conn->query($sel);
						while($row = $rs->fetch_assoc()){
			?>
                <div class="col">
                  <div class="card h-100">
                    <img class="card-img-top" src="../admin/image/<?php echo $row['image'];?>"    width="300" height="200" alt="Card image cap" />
                    <div class="card-body">
                      <h4 class="card-title"><?php echo $row['product_name'] ?></h5>
                     
                      <h6 class="mt-2 text-muted">Product</h6>
                  <div class="card mb-4">
                    <ul class="list-group list-group-flush">
                      <li class="list-group-item">Model: <?php echo $row['model'] ?></li>
                      <li class="list-group-item">Brand: <?php echo $row['brand'] ?></li>
                      
                    </ul>
                  </div>
              
                      <p class="card-text">
                      <?php echo $row['des'] ?>  
                      </p>
                      <p class="card-text">
                        <small class="text-muted">Created Date: <?php echo $row['created_date'] ?></small>
                      </p>
                      <button type="button" class="btn rounded-pill btn-outline-success">
                      ₹ </span> <?php echo $row['price'] ?>
                            </button>


             
                    </div>
                    
                  </div>
                </div>


                <?php
				}
			?>

 <!-- build:js assets/vendor/js/core.js -->
 <script src="../assets/vendor/libs/jquery/jquery.js"></script>
    <script src="../assets/vendor/libs/popper/popper.js"></script>
    <script src="../assets/vendor/js/bootstrap.js"></script>
    <script src="../assets/vendor/libs/perfect-scrollbar/perfect-scrollbar.js"></script>

    <script src="../assets/vendor/js/menu.js"></script>
    <!-- endbuild -->

    <!-- Vendors JS -->
    <script src="../assets/vendor/libs/apex-charts/apexcharts.js"></script>

    <!-- Main JS -->
    <script src="../assets/js/main.js"></script>

    <!-- Page JS -->
    <script src="../assets/js/dashboards-analytics.js"></script>

    <!-- Place this tag in your head or just before your close body tag. -->
    <script async defer src="https://buttons.github.io/buttons.js"></script>
  </body>
</html>












      <?php
    }
      
        ?>
      