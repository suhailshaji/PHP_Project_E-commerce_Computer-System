<?php






   session_start();
   require('../include/config.php');
      if (!empty($_POST))
	  {
			$email=$_POST['email'];
		
		
			$q="select * from user where email='$email' ";
			$res=mysqli_query($conn,$q)or die("wrong query");
			$row=mysqli_fetch_assoc($res);
			if(!empty($row))
			{
				if($_POST['password']!=$row['password'])
				{
					header("Location:user_login.php?pd=1");
					
					
				}
               
			
				else
				{
					$_SESSION=array();
					$_SESSION['email']=$row['email'];
                    $_SESSION['userid']=$row['userid'];
					$email=$row['email'];
					

					header("Location:dashboard.php");
				}
			}	
			
	 
	       else 
	       {
	      header("Location:user_login.php?usr=1");
	      }
	  }	  
?>	  