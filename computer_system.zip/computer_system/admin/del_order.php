<?php
 include '../include/config.php';
 $order_id= $_REQUEST['order_id'];
		$query = "DELETE FROM order_product WHERE order_id= '$order_id'";

        
	$result = $conn->query($query);
	if($result === TRUE){
		echo "<script type = \"text/javascript\">
					alert(\" Successfully Removed \");
					window.location = (\"view_cancel_order.php\")
				</script>";
	}
?>
