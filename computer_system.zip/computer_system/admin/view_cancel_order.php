
<?php include('admin_header.php'); ?>
<div class="content-wrapper">
            <!-- Content -->

            <div class="container-xxl flex-grow-1 container-p-y">
              <h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light">Order Master/</span> Cancelled  Order</h4>

            <h6 class="pb-1 mb-4 text-muted">Products</h6>
            


                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-body">
                                <h4 class="card-title">Cancelled Order</h4>
                                <div class="table-responsive">
                                    <table class="table table-striped table-bordered zero-configuration">
                                        <thead>
                                            <tr>
                                                <th>Order ID</th>
                                                <th> Date </th>
                                                <th>Customer Name</th>
                                                <th>Product </th>
                                                <th>Price</th>
                                                <th>Address</th>
                                                <th>City</th>
                                                <th>Email</th>
                                             
                                                <th>Accpet </th>
                                                <th>Cancel</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                <?php 
                                          include '../include/config.php';
                                  
                                          $sql ="SELECT * FROM order_product join user inner join product where
                                           user.userid=order_product.userid and product.pid=order_product.pid and order_product.status='cancel'";
                                          $qsql = mysqli_query($conn,$sql);
                                          while($rs = mysqli_fetch_array($qsql))
                                          
                                     {
                                        
                                          echo "<tr>
                      
                                          <td>&nbsp;$rs[order_id]</td>	 
                                          <td>&nbsp;$rs[order_date]</td>
                                          <td>&nbsp;$rs[name]</td>
                                          <td>&nbsp;$rs[product_name]</td> 
                                          <td  class='red'>₹&nbsp;$rs[price]</td>
                                          <td>&nbsp;$rs[address]</td>  
                                          <td>&nbsp;$rs[city]</td> 
                                          <td>&nbsp;$rs[email]</td> 
                                          <td>		
                                          <a href='accept_order.php?order_id=$rs[order_id]' class='btn btn-success btn-sm'>   Accept</a> </td>
                                         <td> <a href='del_order.php?order_id=$rs[order_id]' class='btn btn-danger btn-sm'> </i> Delete</a>  </td>
                                          ";
                                         
                                         
                                     } ?>
                                          
                                               
                                              

                                       
                                     
                                         
                                        
                                              
		
			      </tbody>


                                          
                                    </table>
                                        <tbody>
                                        <tbody>
            

 <!-- build:js assets/vendor/js/core.js -->
 <script src="../assets/vendor/libs/jquery/jquery.js"></script>
    <script src="../assets/vendor/libs/popper/popper.js"></script>
    <script src="../assets/vendor/js/bootstrap.js"></script>
    <script src="../assets/vendor/libs/perfect-scrollbar/perfect-scrollbar.js"></script>

    <script src="../assets/vendor/js/menu.js"></script>
    <!-- endbuild -->

    <!-- Vendors JS -->
    <script src="../assets/vendor/libs/apex-charts/apexcharts.js"></script>

    <!-- Main JS -->
    <script src="../assets/js/main.js"></script>

    <!-- Page JS -->
    <script src="../assets/js/dashboards-analytics.js"></script>

    <!-- Place this tag in your head or just before your close body tag. -->
    <script async defer src="https://buttons.github.io/buttons.js"></script>
  </body>
</html>
