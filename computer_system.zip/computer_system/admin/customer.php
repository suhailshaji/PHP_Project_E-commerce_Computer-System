
<?php include('admin_header.php'); ?>
<div class="content-wrapper">
            <!-- Content -->

            <div class="container-xxl flex-grow-1 container-p-y">
              <h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light">Customer/</span> View Customer</h4>

            <h6 class="pb-1 mb-4 text-muted">Customer</h6>
            


                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-body">
                                <h4 class="card-title">Customer Details</h4>
                                <div class="table-responsive">
                                    <table class="table table-striped table-bordered zero-configuration">
                                        <thead>
                                            <tr>
                                                <th>User ID</th>
                                                <th> Mobile </th>
                                                <th>Address</th>
                                                <th>City </th>
                                                <th>Email</th>
                                             
                                            </tr>
                                        </thead>
                                        <tbody>
                <?php 
                                          include '../include/config.php';
                                  
                                          $sql ="SELECT * FROM user ";
                                          $qsql = mysqli_query($conn,$sql);
                                          while($rs = mysqli_fetch_array($qsql))
                                          
                                     {
                                        
                                          echo "<tr>
                      
                                          <td>&nbsp;$rs[userid]</td>	 
                                         
                                          <td>&nbsp;$rs[name]</td>
                                          <td>&nbsp;$rs[mobile]</td>
                                          <td>&nbsp;$rs[address]</td>  
                                          <td>&nbsp;$rs[city]</td> 
                                          <td>&nbsp;$rs[email]</td> 
                                        ";
                                         
                                         
                                     } ?>
                                          
                                               
                                              

                                       
                                     
                                         
                                        
                                              
		
			      </tbody>


                                          
                                    </table>
                                        <tbody>
                                        <tbody>
            

 <!-- build:js assets/vendor/js/core.js -->
 <script src="../assets/vendor/libs/jquery/jquery.js"></script>
    <script src="../assets/vendor/libs/popper/popper.js"></script>
    <script src="../assets/vendor/js/bootstrap.js"></script>
    <script src="../assets/vendor/libs/perfect-scrollbar/perfect-scrollbar.js"></script>

    <script src="../assets/vendor/js/menu.js"></script>
    <!-- endbuild -->

    <!-- Vendors JS -->
    <script src="../assets/vendor/libs/apex-charts/apexcharts.js"></script>

    <!-- Main JS -->
    <script src="../assets/js/main.js"></script>

    <!-- Page JS -->
    <script src="../assets/js/dashboards-analytics.js"></script>

    <!-- Place this tag in your head or just before your close body tag. -->
    <script async defer src="https://buttons.github.io/buttons.js"></script>
  </body>
</html>
