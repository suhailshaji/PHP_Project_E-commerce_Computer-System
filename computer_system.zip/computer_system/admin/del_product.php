<?php
 include '../include/config.php';
	$pid= $_REQUEST['pid'];
		$query = "DELETE FROM product WHERE pid= '$pid'";

        
	$result = $conn->query($query);
	if($result === TRUE){
		echo "<script type = \"text/javascript\">
					alert(\" Successfully Removed \");
					window.location = (\"view_product.php\")
				</script>";
	}
?>
