
<?php include('admin_header.php'); ?>
<div class="content-wrapper">
            <!-- Content -->

            <div class="container-xxl flex-grow-1 container-p-y">
              <h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light">Product Master /</span> View Product</h4>

            <h6 class="pb-1 mb-4 text-muted">Products</h6>
            
              <div class="row row-cols-1 row-cols-md-4 g-4 mb-5">
              <?php
						  include '../include/config.php';
						$sel = "SELECT * FROM product  ";
						$rs = $conn->query($sel);
						while($row = $rs->fetch_assoc()){
			?>
                <div class="col">
                  <div class="card h-100">
                    <img class="card-img-top" src="image/<?php echo $row['image'];?>"    width="300" height="200" alt="Card image cap" />
                    <div class="card-body">
                      <h4 class="card-title"><?php echo $row['product_name'] ?></h5>
                     
                      <h6 class="mt-2 text-muted">Product</h6>
                  <div class="card mb-4">
                    <ul class="list-group list-group-flush">
                      <li class="list-group-item">Model: <?php echo $row['model'] ?></li>
                      <li class="list-group-item">Brand: <?php echo $row['brand'] ?></li>
                      
                    </ul>
                  </div>
              
                      <p class="card-text">
                      <?php echo $row['des'] ?>  
                      </p>
                      <p class="card-text">
                        <small class="text-muted">Created Date: <?php echo $row['created_date'] ?></small>
                      </p>
                      <button type="button" class="btn rounded-pill btn-outline-success">
                      ₹ </span> <?php echo $row['price'] ?>
                            </button>


             <a href='del_product.php?pid=<?php echo $row['pid'] ?>' class="btn rounded-pill btn-outline-danger">  </i> Delete</a> &nbsp;&nbsp;
                    </div>
                    
                  </div>
                </div>


                <?php
				}
			?>

 <!-- build:js assets/vendor/js/core.js -->
 <script src="../assets/vendor/libs/jquery/jquery.js"></script>
    <script src="../assets/vendor/libs/popper/popper.js"></script>
    <script src="../assets/vendor/js/bootstrap.js"></script>
    <script src="../assets/vendor/libs/perfect-scrollbar/perfect-scrollbar.js"></script>

    <script src="../assets/vendor/js/menu.js"></script>
    <!-- endbuild -->

    <!-- Vendors JS -->
    <script src="../assets/vendor/libs/apex-charts/apexcharts.js"></script>

    <!-- Main JS -->
    <script src="../assets/js/main.js"></script>

    <!-- Page JS -->
    <script src="../assets/js/dashboards-analytics.js"></script>

    <!-- Place this tag in your head or just before your close body tag. -->
    <script async defer src="https://buttons.github.io/buttons.js"></script>
  </body>
</html>
