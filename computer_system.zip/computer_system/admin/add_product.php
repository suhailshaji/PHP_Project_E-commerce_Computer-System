

<?php include('admin_header.php'); ?>


<div class="content-wrapper">
            <!-- Content -->

            <div class="container-xxl flex-grow-1 container-p-y">
              <h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light">Product Master/</span>Add Product </h4>

              <!-- Basic Layout -->
              <div class="row">
                <div class="col-xl">
                  <div class="card mb-4">
                    <div class="card-header d-flex justify-content-between align-items-center">
                      <h5 class="mb-0">Add Product</h5>
                    
                    </div>
                    <div class="card-body">
                      <form method="POST" enctype="multipart/form-data">
                        <div class="mb-3">
                          <label class="form-label" for="basic-default-fullname">Product Name</label>
                          <input type="text" class="form-control" id="basic-default-fullname" name ="product_name" placeholder="Product Name" />
                        </div>
                        <div class="mb-3">
                          <label class="form-label" for="basic-default-company">Model</label>
                          <input type="text" class="form-control" id="basic-default-company" name="model" placeholder="Model" />
                        </div>
                        <div class="mb-3">
                          <label class="form-label" for="basic-default-company">Brand</label>
                          <input type="text" class="form-control" id="basic-default-company" name="brand" placeholder="Brand" />
                        </div>
                        <div class="mb-3">
                          <label class="form-label" for="basic-default-company">Price</label>
                          <input type="text" class="form-control" id="basic-default-company" name="price" placeholder="Price" />
                        </div>
                        <div class="mb-3">
                          <label class="form-label" for="basic-default-company">Description</label>
                          <input type="text" class="form-control" id="basic-default-company" name="des" placeholder="Description" />
                        </div>
                        <div class="mb-3">
                          <label class="form-label" for="basic-default-company">Upload Image</label>
                          <input type="file" class="form-control" id="inputGroupFile01"  name="image" />
                        </div>
                       
                        
                       
                        <input class="btn btn-primary d-grid " type="submit" name="submit" value="Submit"><br>
                      </form>


                        
                      <?php
                  if(isset($_POST["submit"]))
                  {
                    
                    
                      include '../include/config.php';
                      {

                      	
						$target_path = "image/";
						$target_path = $target_path . basename ($_FILES['image']['name']);
						if(move_uploaded_file($_FILES['image']['tmp_name'], $target_path)){
								
						$image = basename($_FILES['image']['name']);

                        $product_name = $_POST['product_name']; 
                        $model = $_POST['model'];
                        $brand = $_POST['brand'];
                        $des = $_POST['des'];
                        $price =$_POST['price'];
                        $currentdate = date('Y-m-d');


                        {

                      $sql="insert into product(product_name,model,brand,price,des,created_date,image,p_status)VALUES
                      ('$product_name','$model','$brand','$price','$des','$currentdate','$image','Active')";
                      if(mysqli_query($conn,$sql))
                          {
                        echo "<script type = \"text/javascript\">
                                      alert(\"Succesfully Registered\");
                                                          window.location = (\"view_product.php\")
                                                          
                                      
                                      </script>";
  
                          }   
                         else
                         {
                          echo mysqli_error($conn);
                         }
                      }
                         mysqli_close($conn);
                     } }
                    }
                        ?>

                    


                    </div>
                  </div>
                </div>
              
            </div>

             <!-- build:js assets/vendor/js/core.js -->
    <script src="../assets/vendor/libs/jquery/jquery.js"></script>
    <script src="../assets/vendor/libs/popper/popper.js"></script>
    <script src="../assets/vendor/js/bootstrap.js"></script>
    <script src="../assets/vendor/libs/perfect-scrollbar/perfect-scrollbar.js"></script>

    <script src="../assets/vendor/js/menu.js"></script>
    <!-- endbuild -->

    <!-- Vendors JS -->
    <script src="../assets/vendor/libs/apex-charts/apexcharts.js"></script>

    <!-- Main JS -->
    <script src="../assets/js/main.js"></script>

    <!-- Page JS -->
    <script src="../assets/js/dashboards-analytics.js"></script>

    <!-- Place this tag in your head or just before your close body tag. -->
    <script async defer src="https://buttons.github.io/buttons.js"></script>
  </body>
</html>
