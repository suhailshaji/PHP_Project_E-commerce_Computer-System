<?php
 include '../include/config.php';
	$order_id= $_REQUEST['order_id'];

    $query = "UPDATE order_product SET status = 'cancel' WHERE order_id ='$_REQUEST[order_id]'";
        
	$result = $conn->query($query);
	if($result === TRUE){
		echo "<script type = \"text/javascript\">
					alert(\" Updated \");
					window.location = (\"new_order.php\")
				</script>";
	}
   ?>
   <meta content="4; request.php" http-equiv="refresh" />
